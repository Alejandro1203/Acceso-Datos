package com.iesbelen.dam.acdat.spring.apirest_vf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestVfApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.iesbelen.dam.acdat.spring.apirest_vf.modelo.dto;

public class DepartamentosDTO {
}

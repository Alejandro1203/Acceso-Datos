package com.iesbelen.dam.acdat.spring.apirest_vf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestVfApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestVfApplication.class, args);
    }

}

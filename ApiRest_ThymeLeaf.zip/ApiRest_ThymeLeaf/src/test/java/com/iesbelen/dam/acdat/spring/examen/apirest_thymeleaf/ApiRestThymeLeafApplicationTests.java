package com.iesbelen.dam.acdat.spring.examen.apirest_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestThymeLeafApplicationTests {

    @Test
    void contextLoads() {
    }

}

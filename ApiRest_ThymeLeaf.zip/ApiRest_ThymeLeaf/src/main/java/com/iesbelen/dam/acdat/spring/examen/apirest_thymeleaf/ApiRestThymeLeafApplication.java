package com.iesbelen.dam.acdat.spring.examen.apirest_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestThymeLeafApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestThymeLeafApplication.class, args);
    }

}

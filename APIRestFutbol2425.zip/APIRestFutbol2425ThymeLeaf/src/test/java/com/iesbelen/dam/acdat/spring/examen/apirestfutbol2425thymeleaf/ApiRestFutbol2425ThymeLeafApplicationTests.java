package com.iesbelen.dam.acdat.spring.examen.apirestfutbol2425thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestFutbol2425ThymeLeafApplicationTests {

    @Test
    void contextLoads() {
    }

}

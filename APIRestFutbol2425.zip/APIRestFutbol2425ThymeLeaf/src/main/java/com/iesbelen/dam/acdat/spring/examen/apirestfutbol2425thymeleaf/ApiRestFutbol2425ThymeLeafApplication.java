package com.iesbelen.dam.acdat.spring.examen.apirestfutbol2425thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestFutbol2425ThymeLeafApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestFutbol2425ThymeLeafApplication.class, args);
    }

}

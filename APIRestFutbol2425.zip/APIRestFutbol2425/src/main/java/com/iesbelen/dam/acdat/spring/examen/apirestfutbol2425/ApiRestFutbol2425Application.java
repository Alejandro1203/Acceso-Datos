package com.iesbelen.dam.acdat.spring.examen.apirestfutbol2425;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Alejandro Fernández Gómez
 */

@SpringBootApplication
public class ApiRestFutbol2425Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestFutbol2425Application.class, args);
    }

}

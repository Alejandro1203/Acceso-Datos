package com.iesbelen.dam.acdat.spring.examen.apirestfutbol2425.modelos.dtos;

public class PartidoDTO {
}
